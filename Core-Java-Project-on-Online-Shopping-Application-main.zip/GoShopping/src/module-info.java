/**
 * 
 */
/**
 * @author HP
 *
 */
module GoShopping {
}