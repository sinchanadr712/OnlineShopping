package secondproject;


public interface Second {
	 void booking();
	

	public static void main(String[] args) {
		oneteir ob=new oneteir();
		twotier ob1=new twotier();
		threetier ob2=new threetier();
		
		ob.booking();
		ob1.booking();
		ob2.booking();
	}
	
}


