package secondproject;

public class threetier {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

	public void booking() {
		// TODO Auto-generated method stub
		
	}

}
